                                                                         Griggorii@gmail.com

                          Upgrade OS19.10 Ubuntu Focal Fossa 20.04 Repair problem sound


run pulse-audio-fix_by_Griggorii.sh

My support donate https://money.yandex.ru/to/410014999913799 my em Griggorii@gmail.com
