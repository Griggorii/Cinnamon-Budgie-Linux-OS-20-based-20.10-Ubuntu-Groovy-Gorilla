#!/bin/bash

cat << EOF > pulseaudio.desktop
[Desktop Entry]
Type=Application
Exec=pulseaudio
Hidden=false
NoDisplay=false
X-GNOME-Autostart-enabled=true
Name[ru]=pulseaudio
Name=pulseaudio
Comment[ru]=pulseaudio
Comment=pulseaudio
EOF
chmod -R a+rwx pulseaudio.desktop && mv pulseaudio.desktop ~/.config/autostart && ~/.config/autostart/pulseaudio.desktop && notify-send -i info "Звуковое устройство pulse-audio включено перезайдите в систему что бы инициализировать аудио устройство ! https://money.yandex.ru/to/410014999913799" 
