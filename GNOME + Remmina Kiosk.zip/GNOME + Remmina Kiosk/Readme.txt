                                                                       Griggorii@gmail.com

     Test experiment new desktop de in gnome 

    install remmina

     sudo cp GNOME + Remmina Kiosk.desktop /usr/share/xsessions
